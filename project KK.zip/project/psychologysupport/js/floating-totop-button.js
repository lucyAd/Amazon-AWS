(function( $ ) {

    // all configurations
    var config;

    // helper function to determine mobile visibility
    function showMobile(){
        return config.mobileHide == 0 || $(window).width() >= config.mobileHide;
    }

    // helper function to determine scroll visibility
    function showScroll(){
        return $(window).scrollTop() >= config.scrollTrigger
    }

    // append callback click events
    function addClickEvents(){
        var selector = config.clickSelectors.join(',');
        selector = config.clickSelectors.length > 0 ? ',' + selector : '';
        $('a.' + config.buttonClass + selector).click(config.animateScroll.bind(config));
    }

    // append callback scroll event
    function addScrollEvent(){
        $(window).scroll(config.fadeScroll.bind(config));
    }

    // append callback resize hide event
    function addResizeEvent(){
        $(window).resize(config.resizeHide.bind(config));   
    }

    // add button to DOM
    function appendButton(that){
        var opClass = ' op-' + config.opacity;
        var shClass = ' sh-' + config.shape;
        var bpClass = ' bp-' + config.position;
        var bmClass = ' bm-' + config.margin;
        var szClass = ' sz-' + config.size;
        var bwClass = ' bw-' + config.border.width;
        var filterClass = '';
        var hideClass = '';
        var isClass = '';
        var bsClass = '';
        var pClass = '';

        var imgCClasses = config.imgClasses.join(' ');
        var linkCClasses = config.linkClasses.join(' ');
        var linkClasses = '';
        var imgClasses = '';

        var linkStyle = '';
        var imgPath = '';
        var iconColor = '';

        // determine icon color
        iconColor = config.iconColor == 'b' ? 'b' : 'w';

        // image path
        imgPath = config.imagePath + '/' + iconColor + '/' + config.arrowType + '.svg';

        // border
        bwClass = bwClass + iconColor;

        // shadows
        if(config.iconShadow != '')
            isClass = ' is-' + config.iconShadow ;

        if(config.btnShadow != '')
            bsClass = ' bs-' + config.btnShadow;

        // palette
        if(config.palette != '')
            pClass = ' p-' + config.palette.toLowerCase();

        // auto hide
        if(config.autoHide)
            hideClass = ' hide';

        // filter
        if(config.filter)
            filterClass = ' filter';

        // build styles 
        if(config.border.color != '' || config.backgroundColor != '' || !showMobile()){
            var boColor = 'border-color:' + config.border.color;
            var bgColor = 'background-color:' + config.backgroundColor;
            var display = !showMobile() ? 'display:none' : '';
            linkStyle = ' style="' + bgColor + ';' + boColor + ';' + display + '"';
        }

        // build custom classes 
        imgCClasses = imgCClasses.length > 0 ? imgCClasses + ' ' : imgCClasses;
        linkCClasses = linkCClasses.length > 0 ? linkCClasses + ' ' : linkCClasses;

        // build link and image classes
        linkClasses = config.buttonClass + opClass + shClass + bpClass +  bmClass + pClass + szClass 
                    + bwClass + bsClass + hideClass + filterClass + linkCClasses;

        imgClasses = config.imgClass + isClass + ' ' + config.arrowType + '-img' + imgCClasses;

        // append to DOM
        $(that).prepend('<a href="#" class="' + linkClasses + '"' + linkStyle 
                        + '><img src="' + imgPath + '" class="' + imgClasses + '"></a>');
    }

    // append button and create events
    $.fn.toTopButton = function(options) {
        config = $.extend(true, {}, $.fn.toTopButton.defaults, options);

        appendButton(this);
        addScrollEvent();
        addClickEvents();
        addResizeEvent();
        config.resizeHide();
    };
    $.fn.toTopButton.defaults = {
        imagePath: './img/icons',
        arrowType: 'arrow', //
        scrollTrigger: 300,
        animationTime: 700,
        opacity: 20,
        shape: 10,
        margin: 2,
        palette: '',
        iconColor: 'w',
        backgroundColor: '',
        border : { 
            width: 0,
            color: ''
        },
        position: 'br',
        size: 4,
        fadeInSpeed: 'fast',
        fadeOutSpeed: 'fast',
        iconShadow: 4,
        btnShadow: 2,
        mobileHide: 768,
        autoHide: true,
        filter: true,
        buttonClass: 'to-top-button',
        imgClass: 'arrow-img',
        linkClasses: [],
        imgClasses: [],
        clickSelectors: [],

        // scroll animation method
        animateScroll: function(){
            $('html, body').animate({scrollTop: 0}, this.animationTime);
            return false;
        },

        // fade scroll method
        fadeScroll: function() {
            var btn = $('a.' + config.buttonClass);
            if(this.autoHide && showMobile(this)){
                if(showScroll(this)) {
                    if(!$(btn).is(':visible'))
                        $(btn).fadeIn(this.fadeInSpeed);
                }else{
                    if($(btn).is(':visible'))
                        $(btn).fadeOut(this.fadeOutSpeed);
                }
            }
        },

        // resize hide method
        resizeHide: function() {
            if(showMobile(this) && showScroll(this))
                $('.' + config.buttonClass).css('display', 'inline');
            else
                $('.' + config.buttonClass).css('display', 'none');
        }
    };
 
})( jQuery );