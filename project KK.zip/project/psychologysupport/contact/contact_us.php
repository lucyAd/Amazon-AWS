
<?php 
include('../config/db.php');
       if(isset($_POST['submit']))
        {
		$Email=$_POST['Email'];
       $Password=$_POST['Password'];		
            $user = mysqli_query($conn,"SELECT * FROM login WHERE Email ='$Email' and Password='$Password'");
					if(mysqli_num_rows($user)==1)
		{
			session_start();
		$_SESSION['Email']=$Email;
			$s=2;
			if($s==2)
			{
			header('Location:/psychologysupport/index.php');
			
		}
		}
	        else
		{
			echo '<script language="javascript">';
echo ' swal({
                    title: "Sorry!",
                    text: "User Name And Password Incorrect",
                    icon: "Sorry"
                    });';
echo '</script>';
			
			
		}	
        }
?>
<html>
<head>
	<title>Psychology Support</title>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../css/_variables.scss">
  <!-- CSS================================================== -->
  <!-- bootstrap.min -->
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
  <!-- bootstrap.min -->
    <link rel="stylesheet" type="text/css" href="../css/owl.carousel.css">
  <!-- bootstrap.min -->
    <link rel="stylesheet" type="text/css" href="../css/animate.css">
  <!-- Main Stylesheet -->
    <link rel="stylesheet" type="text/css" href="../css/mycustom.css">
    <link href="../css/floating-totop-button.css" rel="stylesheet">
  <!-- Modernizer Script for old Browsers -->
    <script src="../js/modernizr-2.6.2.min.js"></script>
	 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 
</head>
<body style="background-image: url(../img/bl1.jpg);background-size: 100% 100%;background-position:center;">
<!--Fixed Navigation==================================== -->
    <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header">

        <div class="container-fluid">
            <div class="navbar-header">
                <!-- responsive nav button -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
                </button>
				<!-- /responsive nav button -->
				<!-- logo -->
				<h1 class="navbar-brand">
					<a href="#body" style="text-decoration: none;">
              <img src="../img/logo.jpg" style="margin-top: -14px;" align="">
					</a>
				</h1>
				<!-- /logo -->
            </div>
			<!-- main nav -->
            <nav class="collapse navbar-collapse navbar-right" role="navigation">
                <ul id="nav" class="nav navbar-nav menu">
                  <li><a href="../#coach.php"><span>Home</span></a></li>
                  <li><a href="../#coach.php"><span>About</span></a></li>
                  <li><a href="../#coach.php"><span>Support-Group</span></a></li>
                  <li><a href="../#coach.php"><span>Coaches and Counselors</span></a></li>
                  <li><a href="../#coach.php"><span>Volunteer Listeners</span></a></li>
                  <li><a href="../coach.php"><span>Blog</span></a></li>
                  <li><a href="../#coach.php"><span>Contact</span></a></li>
                  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Registration<span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a target="_blank" href="../contact/contact_us.php">Login</a></li>
                  <li><a target="_blank" href="../contact/Sign up.php">Sign Up</a></li>
                  <li><a target="_blank" href="../contact/Sign up.php">Apoirment</a></li>
                </ul>
              </li>
                </ul>
            </nav>
			<!-- /main nav -->
        </div>
    </header><!--End Fixed Navigation==================================== -->
  <section id="home-slider"><!--Home Slider==================================== -->
    <div class="container-fluid">
      <div class="row">
        <div class="contact_us">
          <div class="contact_img animated fadeInDown"></div>
            <div class="caption-content">
            </div>
        </div>
      </div>
    </div>
  </section><!--End Home SliderEnd==================================== -->
  <section>
    <div style="width:500px; margin:auto; background-color:#FFF; border-radius:10px; border-style:dashed;" class="animated bounceInRight">
      <form method="post" action="">
        <table width="100%" height="196"  align="center">
          <tr>
            <td width="12%" height="34" align="center">
              <img src="../img/log.png" width="40" height="40">
            </td>
            <td width="30%"><b>Login Id:</b></td>
            <td width="58%">
              <input type="text" name="Email" id="id" placeholder="Your Login Id" required="required" style ="height:27px; border-radius:5px; color:blue; border-color:red; border-bottom-style: dotted;" size="30"/>
            </td>
          </tr>
          <tr>
            <td height="34" align="center">

              <img src="../img/password.png" width="40" height="40">
            </td>
            <td height="34"><b>Password:</b></td>
            <td>
              <input type="password" name="Password" id="pass" placeholder="Your Password" required="required" style ="height:27px; border-radius:5px; color:blue; border-color:red; border-bottom-style: dotted;" size="30"/>
            </td>
          </tr>
      <tr>
          <td height="39" colspan=""></td>
          <td>
            <button class="button" type="reset"><span>Reset </span></button>
          </td>
          <td>
             <input class="btn btn-primary" type="submit" name="submit" value="register"/>
          </td>
      </tr>
    <tr><td height="39" colspan="2"></td><td>&nbsp;</td></tr>
    </table>
    </form>
	
    </div>
  </section>












<!-- Essential jQuery Plugins================================================== -->
<!-- Main jQuery -->
<script src="../js/jquery.min.js"></script>
<!--<script src="js/jquery-1.11.1.min.js"></script>-->
<!--<script src="js/bootstrap.min.js"></script>-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!-- Single Page Nav -->
<script src="../js/jquery.singlePageNav.min.js"></script>
<!-- Owl Carousel -->
 <script src="../js/owl.carousel.min.js"></script>
<!-- jquery easing -->
<script src="../js/isotope.pkgd.min.js"></script>
<script src="../js/jquery.easing.min.js"></script>
<!-- Fullscreen slider -->
<script src="../js/jquery.slitslider.js"></script>
<script src="../js/jquery.ba-cond.min.js"></script>
<script src="../js/main.js"></script>
<script src="../js/floating-totop-button.js"></script>
<script src="../js/wow.js"></script>
<script src="../js/smoth.js"></script>
<script src="../js/wow.min.js"></script>
<script src="../js/smoth_scrooling.js"></script>
</body>
</html>