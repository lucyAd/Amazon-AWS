

<?php session_start();
?>
<!DOCTYPE html>

<html>
<head>
	<title>Psychology Support</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="../css/_variables.scss">
  <!-- CSS================================================== -->
  <!-- bootstrap.min -->
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
  <!-- bootstrap.min -->
  <link rel="stylesheet" type="text/css" href="../css/owl.carousel.css">
  <!-- bootstrap.min -->
  <link rel="stylesheet" type="text/css" href="../css/animate.css">
  <!-- Main Stylesheet -->
  <link rel="stylesheet" type="text/css" href="../css/mycustom.css">

  <link href="../css/floating-totop-button.css" rel="stylesheet">
  <!-- Modernizer Script for old Browsers -->
  <script src="../js/modernizr-2.6.2.min.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
 
  
</head>
<body>

<h1>
<?php $_SESSION['data']['F_Name']; ?>
</h1>

<!--Fixed Navigation==================================== -->
    <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header">

        <div class="container-fluid">
            <div class="navbar-header">
                <!-- responsive nav button -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
                </button>
				<!-- /responsive nav button -->
				<!-- logo -->
				<h1 class="navbar-brand">
					<a href="#body" style="text-decoration: none;">
              <img src="../img/logo.jpg" style="margin-top: -14px;" align="">
					</a>
				</h1>
				<!-- /logo -->
            </div>
			<!-- main nav -->
          <nav class="collapse navbar-collapse navbar-right" role="navigation">
                <ul id="nav" class="nav navbar-nav menu">
                  <li><a href="../#coach.php"><span>Home</span></a></li>
                  <li><a href="../#coach.php"><span>About</span></a></li>
                  <li><a href="../#coach.php"><span>Support-Group</span></a></li>
                  <li><a href="../#coach.php"><span>Coaches and Counselors</span></a></li>
                  <li><a href="../#coach.php"><span>Volunteer Listeners</span></a></li>
                  <li><a href="../coach.php"><span>Blog</span></a></li>
                  <li><a href="../#coach.php"><span>Contact</span></a></li>
                  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Registration<span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a target="_blank" href="../contact/contact_us.php">Login</a></li>
                  <li><a target="_blank" href="../contact/Sign up.php">Sign Up</a></li>
                  <li><a target="_blank" href="../contact/Sign up.php">Apoirment</a></li>
                </ul>
              </li>
                </ul>
            </nav>
			<!-- /main nav -->
        </div>
    </header><!--End Fixed Navigation==================================== -->
  <section id="home-slider"><!--Home Slider==================================== -->
    <div class="container-fluid">
      <div class="row">
        <div class="contact_us">
          <div class="contact_img_sign animated fadeInDown"></div>
            <div class="caption-content">
            </div>
        </div>
      </div>
    </div>
  </section><!--End Home SliderEnd==================================== -->
  <section>
    <div class="wrapper" style="background-image: url('../img/registration-form-2.jpg');">
      <div class="inner">
        <form action="Sign up.php" method="Post">
          <h3>Registration Form</h3>
          <div class="form-group">
            <div class="form-wrapper">
              <label for="">First Name</label>
              <input type="text" name="F_Name" class="form-control">
            </div>
            <div class="form-wrapper">
              <label for="">Last Name</label>
              <input type="text" name="L_Name" class="form-control">
            </div>
          </div>
          <div class="form-wrapper">
            <label for="">Email</label>
            <input type="text" name="Email" class="form-control">
          </div>
          <div class="form-wrapper">
            <label for="">Password</label>
            <input type="password" name="Password" class="form-control">
          </div>
          <div class="form-wrapper">
            <label for="">Confirm Password</label>
            <input type="password" name="CPassword" class="form-control">
          </div>
          <div class="checkbox">
            <label>
              <input type="checkbox"> I  am accept the Terms of Use & Privacy Policy.
              <span class="checkmark"></span>
            </label>
          </div>
        <input class="btn btn-primary" type="submit" name="submit" value="register"/>
        </form>
      </div>
    </div>
  </section>
  <?php



include('../config/db.php');

   if($_SERVER['REQUEST_METHOD'] == 'POST')
{
$F_Name= $_POST['F_Name'];
$L_Name = $_POST['L_Name'];
$Email = $_POST['Email'];
$Password = $_POST['Password'];
$Confrim_Password=$_POST['CPassword'];



   
    $add_user = "INSERT INTO login(F_Name,L_Name,Email,Password,Confrim_Password) 
	VALUES ('$F_Name','$L_Name','$Email','$Password','$Confrim_Password')";
	$user = mysqli_query($conn,$add_user);
	
    // echo $add_user;




echo '<script language="javascript">';
echo ' swal({
                    title: "Thanks!",
                    text: "You Register Success",
                    icon: "success"
                    });';
echo '</script>';
if(!$user)

{
	
	
echo '<script language="javascript">';
echo ' swal({
                    title: "Error!",
                    text: "Try Again",
                    icon: "Sorry"
                    });';
echo '</script>';
}
}
?>












<!-- Essential jQuery Plugins================================================== -->
<!-- Main jQuery -->
<script src="../js/jquery.min.js"></script>
<!--<script src="js/jquery-1.11.1.min.js"></script>-->
<!--<script src="js/bootstrap.min.js"></script>-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!-- Single Page Nav -->
<script src="../js/jquery.singlePageNav.min.js"></script>
<!-- Owl Carousel -->
 <script src="../js/owl.carousel.min.js"></script>
<!-- jquery easing -->
<script src="../js/isotope.pkgd.min.js"></script>
<script src="../js/jquery.easing.min.js"></script>
<!-- Fullscreen slider -->
<script src="../js/jquery.slitslider.js"></script>
<script src="../js/jquery.ba-cond.min.js"></script>
<script src="../js/main.js"></script>
<script src="../js/floating-totop-button.js"></script>
<script src="../js/wow.js"></script>
<script src="../js/smoth.js"></script>
<script src="../js/wow.min.js"></script>
<script src="../js/smoth_scrooling.js"></script>


</body>
</html>