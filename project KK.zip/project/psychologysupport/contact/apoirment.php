<!DOCTYPE html>
<html>
<head>
	<title>Psychology Support</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="../css/_variables.scss">
  <!-- CSS================================================== -->
  <!-- bootstrap.min -->
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
  <!-- bootstrap.min -->
  <link rel="stylesheet" type="text/css" href="../css/owl.carousel.css">
  <!-- bootstrap.min -->
  <link rel="stylesheet" type="text/css" href="../css/animate.css">
  <!-- Main Stylesheet -->
  <link rel="stylesheet" type="text/css" href="../css/mycustom.css">
  <link rel="stylesheet" type="text/css" href="../css/style.css">
  <link href="../css/floating-totop-button.css" rel="stylesheet">
  <!-- Modernizer Script for old Browsers -->
  <script src="../js/modernizr-2.6.2.min.js"></script>
   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
<!--Fixed Navigation==================================== -->
    <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header">

        <div class="container-fluid">
            <div class="navbar-header">
                <!-- responsive nav button -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
                </button>
				<!-- /responsive nav button -->
				<!-- logo -->
				<h1 class="navbar-brand">
					<a href="#body" style="text-decoration: none;">
              <img src="../img/logo.jpg" style="margin-top: -14px;" align="">
					</a>
				</h1>
				<!-- /logo -->
            </div>
			<!-- main nav -->
            <nav class="collapse navbar-collapse navbar-right" role="navigation">
                <ul id="nav" class="nav navbar-nav menu">
                  <li><a href="../#coach.php"><span>Home</span></a></li>
                  <li><a href="../#coach.php"><span>About</span></a></li>
                  <li><a href="../#coach.php"><span>Support-Group</span></a></li>
                  <li><a href="../#coach.php"><span>Coaches and Counselors</span></a></li>
                  <li><a href="../#coach.php"><span>Volunteer Listeners</span></a></li>
                  <li><a href="../coach.php"><span>Blog</span></a></li>
                  <li><a href="../#coach.php"><span>Contact</span></a></li>
                  <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Registration<span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a target="_blank" href="../contact/contact_us.php">Login</a></li>
                  <li><a target="_blank" href="../contact/Sign up.php">Sign Up</a></li>
                  <li><a target="_blank" href="../contact/Apoirment.php">Apoirment</a></li>
                </ul>
              </li>
                </ul>
            </nav>
			<!-- /main nav -->
        </div>
    </header><!--End Fixed Navigation==================================== -->
    <div class="bg-agile">
  <div class="book-appointment">
  <h2>Make an appointment</h2>
      <form action="" method="post">
      <div class="left-agileits-w3layouts same">
      <div class="gaps">
        <p>Patient Name</p>
          <input type="text" name="Name" placeholder="" required="">
      </div>  
        <div class="gaps">  
        <p>Phone Number</p>
          <input type="text" name="Number" placeholder="" required="">
        </div>
        <div class="gaps">
        <p>Email</p>
            <input type="email" name="Email" placeholder="" required="">
        </div>  
        <div class="gaps">
        <p>Symptoms</p>
            <textarea name="Symptoms" placeholder="" required=""></textarea>
        </div>
      </div>
      <div class="right-agileinfo same">
      <div class="gaps">
        <p>Select Date</p>    
            <input id="datepicker1" name="date" type="date" value="" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" required="" class="hasDatepicker">
      </div>
      <div class="gaps">
        <p>Department</p> 
          <select class="form-control" name="Dapartment">
            <option></option>
            <option>Cardiology</option>
            <option>Ophthalmology</option>
            <option>Neurology</option>
            <option>Psychology</option>
            <option>Dermatology</option>
          </select>
      </div>
      <div class="gaps">
        <p>Gender</p> 
          <select class="form-control" name="Gender">
            <option></option>
            <option>Male</option>
            <option>Female</option>
          </select>
      </div>
      <div class="gaps">
        <p>Time</p>   
          <input type="Time" id="timepicker" name="Time" class="timepicker form-control hasWickedpicker" value="" onkeypress="return false;"> 
      </div>
      </div>
      <div class="clear"></div>
              <input type="submit" name="submit" value="Make an appointment">
      </form>
    </div>
   </div>
  <?php



include('../config/db.php');

    if(isset($_POST['submit']))
{
$Name= $_POST['Name'];
$date = $_POST['date'];
$Number= $_POST['Number'];
$Dapartment = $_POST['Dapartment'];
$Email=$_POST['Email'];
$Gender=$_POST['Gender'];
$Symptoms=$_POST['Symptoms'];
$Time=$_POST['Time'];




   
    $add_user = "INSERT INTO apoiment(Name,date,Number,Dapartment,Email,Gender,Symptoms,Time) 
	VALUES ('$Name','$date','$Number','$Dapartment','$Email','$Gender','$Symptoms','$Time')";
	$user = mysqli_query($conn,$add_user);
	
    // echo $add_user;




echo '<script language="javascript">';
echo ' swal({
                    title: "Thanks!",
                    text: "You Apoirment",
                    icon: "success"
                    });';
echo '</script>';
if(!$user)

{
	
	
echo '<script language="javascript">';
echo ' swal({
                    title: "Error!",
                    text: "Try Again",
                    icon: "Sorry"
                    });';
echo '</script>';
}
}
?>







<!-- Essential jQuery Plugins================================================== -->
<!-- Main jQuery -->
<script src="../js/jquery.min.js"></script>
<!--<script src="js/jquery-1.11.1.min.js"></script>-->
<!--<script src="js/bootstrap.min.js"></script>-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!-- Single Page Nav -->
<script src="../js/jquery.singlePageNav.min.js"></script>
<!-- Owl Carousel -->
 <script src="../js/owl.carousel.min.js"></script>
<!-- jquery easing -->
<script src="../js/isotope.pkgd.min.js"></script>
<script src="../js/jquery.easing.min.js"></script>
<!-- Fullscreen slider -->
<script src="../js/jquery.slitslider.js"></script>
<script src="../js/jquery.ba-cond.min.js"></script>
<script src="../js/main.js"></script>
<script src="../js/floating-totop-button.js"></script>
<script src="../js/wow.js"></script>
<script src="../js/smoth.js"></script>
<script src="../js/wow.min.js"></script>
<script src="../js/smoth_scrooling.js"></script>
</body>
</html>