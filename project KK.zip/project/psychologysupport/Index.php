


<!DOCTYPE html>

<html>
<head>
	<title>Psychology Support</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/_variables.scss">
	<!-- CSS================================================== -->
	<!-- bootstrap.min -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
	<!-- bootstrap.min -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
	<!-- bootstrap.min -->
    <link rel="stylesheet" type="text/css" href="css/animate.css">
	<!-- Main Stylesheet -->
    <link rel="stylesheet" type="text/css" href="css/mycustom.css">
    <link href="css/floating-totop-button.css" rel="stylesheet">
	<!-- Modernizer Script for old Browsers -->
	 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script src="js/modernizr-2.6.2.min.js"></script>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
	
	<!--Fixed Navigation==================================== -->
    <header id="navigation" class="navbar navbar-inverse navbar-fixed-top animated-header">
        <div class="container-fluid">

            <div class="navbar-header">
                <!-- responsive nav button -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<i class="fa fa-bars"></i>
					<i class="fa fa-bars"></i>
					<i class="fa fa-bars"></i>
                </button>
				<!-- /responsive nav button -->
				<!-- logo -->
				<h1 class="navbar-brand">
					<a href="#body" style="text-decoration: none;">
                        <img src="img/logo.jpg" style="margin-top: -14px;" align="">
					</a>
				</h1>
				<!-- /logo -->
            </div>
			<!-- main nav -->
            <nav class="collapse navbar-collapse navbar-right" role="navigation">
                <ul id="nav" class="nav navbar-nav menu">
                	<li><a href="#home-slider"><span>Home</span></a></li>
                	<li><a href="#About"><span>About</span></a></li>
                	<li><a href="#intro"><span>Support-Group</span></a></li>
                	<li><a href="#counselor"><span>Coaches and Counselors</span></a></li>
                	<li><a href="#VOLUNTEER"><span>Volunteer Listeners</span></a></li>
                	<li><a href="#blog_part"><span>Blog</span></a></li>
                	<li><a href="#contact"><span>Contact</span></a></li>
                	<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Registration<span class="caret"></span></a>
				        <ul class="dropdown-menu">
						<?php
Session_start(); 
include('config/db.php');





						?>
						<div hidden>
<?php $name=$_SESSION['Email'];?>
						</div>
						<?php if ($name)
						{ ?>
					Email:<B><li><span style="font-size:15px"><?php echo $name ?></span></li></b>
					 <li><a target="_blank" href="logout.php">Logout</a></li>
					 
					 
					<?php }else 
						{ ?>
					  <li><a target="_blank" href="contact/Sign up.php">Sign Up</a></li>
				          <li><a target="_blank" href="contact/contact_us.php">Login</a></li>
						<?php }?>		         
				        
				          <li><a target="_blank" href="contact/Apoirment.php">Apoirment</a></li>
				        </ul>
				      </li>
                </ul>
            </nav>
			<!-- /main nav -->
        </div>
    </header><!--End Fixed Navigation==================================== -->
 	<section id="home-slider">
 		<div class="page-header">
 			<div class="slider container-fluid">
  				<div id="img-carousel" data-ride="carousel" class="carousel slide">
  				<!-- Indicators-->
  					<ol class="carousel-indicators">
					    <li data-target="#img-carousel" data-slide-to="0" class="active"></li>
					    <li data-target="#img-carousel" data-slide-to="1"></li>
					    <li data-target="#img-carousel" data-slide-to="2"></li>
					</ol>
				  	<!-- Wrapper for slides-->
				  	<div role="listbox" class="carousel-inner">
				    	<div class="item active"><img src="img/top1.jpg" alt="" style="width: 100%; height: 650px;">
				      		<div class="carousel-caption">
						        <h2 class="animated bounceInDown">MENTAL HEALTH<span style="color: #ff1784"> SUPPORT ONLINE</span></h2>
						        <p class="animated bounceInUp">Beyond Limits, Exceed expectations, Discover your full potential</p>
						        <p class="animated bounceInRight"><a href="contact_us.php" class="btn btn-green btn-effect">WELCOME</a></p>
					      	</div>
    					</div>
    					<div class="item"><img src="img/slider2.jpg" alt=""/style="width: 100%; height: 650px;">
      						<div class="carousel-caption">
						        <h2 class="animated bounceInTop">MENTAL HEALTH<span style="color: #ff1784"> SUPPORT ONLINE</span></h2>
						        <p class="animated bounceInLeft">Beyond Limits, Exceed expectations, Discover your full potential</p>
						        <p class="animated bounceInRight"><a href="contact_us.php" class="btn btn-green btn-effect">WELCOME</a></p>
					      	</div>
    					</div>
					    <div class="item"><img src="img/slider3.jpg" alt=""/style="width: 100%; height: 650px;">
					      	<div class="carousel-caption">
						        <h2 class="animated bounceInLeft">MENTAL HEALTH<span style="color: #ff1784"> SUPPORT ONLINE</span></h2>
						        <p class="animated bounceInUp">Beyond Limits, Exceed expectations, Discover your full potential</p>
						        <p class="animated bounceInRight"><a href="contact_us.html" class="btn btn-green btn-effect">WELCOME</a></p>
					      	</div>
					    </div>
  					</div>
  					<!-- Controls--><a href="#img-carousel" role="button" data-slide="prev" class="left carousel-control">
  						<i aria-hidden="true" class="fa fa-chevron-left"></i>
  						<span class="sr-only">Previous</span></a>
  						<a href="#img-carousel" role="button" data-slide="next" class="right carousel-control">
  							<i aria-hidden="true" class="fa fa-chevron-right"></i>
  							<span class="sr-only">Next</span></a>
				</div>
			</div>
		</div>
 	</section>

	
    <section class="about" id="About"><!--start about section==================================== -->
        <div class="container-fluid">
            <div class="row">
                <div class="title-main-w3ls wow fadeInDown">
                    <h2 style="color: black;">About<span style="color: #ff1784;">Us</span></h2><br>
                </div>
                <div class="about-top-agileits-w3layouts">
                    <div class="col-md-12 about-right-w3-agileits">
                        <!--<h3 style="font-size: 34px;" class="wow fadeInRight">Relapse Prevention, Emotional and Psychological Support</h3>-->
                        <!--<div class="about_us_img col-sm-6 col-md-6 col-lg-6">
                            <img src="img/Top.jpg" style="width: 100%; height:274px;" class="wow fadeInLeft">
                        </div>-->
                        <p class="para-agileits-w3layouts black-w3ls col-sm-12 col-md-12 col-lg-12 wow fadeInRight" style="text-align: justify;">We provide an online psychological and emotional support platform developed to promote better mental health. It anonymously connects you with the right mental counselors and people with deep and fertile life experiences, who understand you and help you to overcome your fears and develop a better understanding of your life. Our goal is to help patients perceive their mental health problems along with creating a room of improvement in life. Our vision is to enable you to live a happier, more meaningful, and satisfying life by shattering the stigmas associated with emotional and mental health. </p>
                    
                    </div>
                    <div class="clearfix"> </div>
                </div>
            </div>
        </div>
    </section><!--End about section==================================== -->
	<section class="about" id=""><!--start about section==================================== -->
    	<div class="container-fluid">
    		<div class="row">
    			<div class="title-main-w3ls wow fadeInDown">
                    <h2 style="color: black;">WHAT <span style="color: #ff1784;">WE DO</span></h2>
        		</div>
        		<div class="about-top-agileits-w3layouts">
            		<div class="col-md-12 about-right-w3-agileits">
                		<h3 style="font-size: 34px;" class="wow fadeInRight">Relapse Prevention, Emotional and Psychological Support</h3>
                		<p class="para-agileits-w3layouts black-w3ls col-sm-12 col-md-12 col-lg-12 wow fadeInRight" style="text-align: justify;">Emotional and psychological problems like depression and anxiety, mood disorders, etc can be alleviated by talking to loved ones, however when people have geographic distance, life can be difficult to manage and mental health can deteriorate further. To help people who lack an emotional and psychological support network, we have created an online support platform known as coaching-emotional-support Platform. This is the leading global emotional remote support platform. This platform unites and anonymously connects people from different parts of the world who are recovering from different emotional and psychological problems like anxiety, depression, violence, abuse or addiction, etc. Maybe you are anxious or plagued? Maybe you are struggling with a mental condition and need guidance, clarity, or support? This forum permits you to post any emotional or mental health problem you are facing and receive feedback from other members who may have tolerated a similar problem. It also facilitates peer to peer or family to family support...<a href="contact_us.html" class="btn btn-yellow btn-effect">Read More</a></p>
                    
            		</div>
            		<div class="clearfix"> </div>
        		</div>
        		<div class="about-btm-wthree">
            		<div class="col-md-3 about-w3-grids wow fadeInRight">
                		<h4>Support Groups</h4>
                		<p class="para-agileits-w3layouts">Different peer to peer support groups to connect recovering patients</p>
            		</div>
            		<div class="col-md-3 about-w3-grids wow fadeInRight">
                		<h4>Experts Discussion Board</h4>
                		<p class="para-agileits-w3layouts">Experts can choose any topic of interest and start discussions which recovering can join,it is ask questions or make contribution</p>
            		</div>
            		<div class="col-md-3 about-w3-grids wow fadeInLeft">
		                <h4>Families Support</h4>
		                <p class="para-agileits-w3layouts">Families of recovering patients can join to support eash other</p>
            		</div>
            		<div class="col-md-3 about-w3-grids wow fadeInLeft">
		                <h4>Coaching and Counseling</h4>
		                <p class="para-agileits-w3layouts">One can book session privately with a coach or counselor</p>
            		</div>
            		<div class="clearfix"></div>
        		</div>
    		</div>
    	</div>
	</section><!--End about section==================================== -->

	<section id="intro"><!--start Support-Group section==================================== -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 wow fadeInRight">
                    <h2 style="color: black;">AWESOME <span style="color: #ff1784;">Support-Groups</span></h2>
                    <br>
                    <p class="text-size-18">Searching for online support groups for depression, anxiety, violence, abuse, addiction, bipolar disease, and other mental condition? Support groups can play a major role in coping with and overcoming mental health conditions. They provide healing components to a variety of mental challenges. Support groups can be miraculous and life-changing.  A support group among different people with shared experiences can serve as a channel between emotional and medical needs. Mental Health Support Online provides support groups about any topic, concern, or mental health condition. You can choose a support group depending upon your mental condition and needs. This procedure will be completely anonymous. Furthermore, you are free to comment, post questions, book a session with the counselor, or start a new discussion. </p>
                </div>
            	<div class="vs-30"></div>
                <div class="col-sm-3 col-md-3 col-lg-3">
                    <div class="intro-item-wrap wow fadeInRight">
                        <div class="intro-item-icon">
                            <i class="fa fa-users"></i>
                        </div>
                        <div class="intro-item-text">
                            <h3>Families Support Group</h3>
                            <p style="text-align: justify;">Designed for the families of patients with mental illness to talk, share their experiences, and support each other. It is an imperative resource for families who have loved ones with mental illness. Assisting a loved one who is suffering from a serious mental illness can be very difficult and painful for family members. Connecting with the other families who had the same experience can provide understanding and support to the families who are trying to help someone with a mental condition or addiction. Our family support group provides a safe platform to share your experience and learn ideas that will help you support your loved one living with mental or addiction challenges.</p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    	<hr>
                    <div class="intro-item-wrap wow fadeInRight">
                        <div class="intro-item-icon">
                            <i class="fa fa-stethoscope"></i>
                        </div>
                        <div class="intro-item-text">
                            <h3>Anxiety Support Group</h3>
                            <p style="text-align: justify;">This type of support group is beneficial for people suffering from different stages of anxiety. If you are living with anxiety, joining an anxiety support group can be an effective part of your recovery. Mental Health Support Online offers an anxiety support group that enables you to create connections and create an effectual support network. Taking with different people who relate to your mental problems will help you acquire new skills for handling anxiety. Moreover, it will provide better knowledge and recognition of anxiety disorders. </p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    <hr>
                    <div class="intro-item-wrap wow fadeInRight">
                        <div class="intro-item-icon">
                            <i class="fa fa-heart-o "></i>
                        </div>
                       	<div class="intro-item-text">
                            <h3>Psychological First Aid</h3>
                            <p style="text-align: justify;">Mental health volunteer listeners play an important role in countering mental disasters. These are helpers trained to provide psychological first aid. At Mental Health Support Online, we have hundreds of anonymously registered professional mental health volunteer listeners. Employing their therapeutic skills and training, these volunteers offer assurance and support, function as advocates, and help victims deal with their conditions.</p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    <hr>
                    <div class="intro-item-wrap wow fadeInRight">
                        <div class="intro-item-icon">
                            <i class="fa fa-heart-o "></i>
                        </div>
                        <div class="intro-item-text">
                            <h3>Cyber Abuse Support Group</h3>
                            <p style="text-align: justify;">Cyber abuse and bullying can lead to serious mental health problems including depression, anxiety, feeling embarrassed, vulnerable, and even suicidal. However, there are different ways to prevent yourself and your kids from the serious impacts of cyber abuse and bullying. Our cyber abuse and bullying support group is developed to help people overcome mental problems associated with cyberbullying. By connecting with other members who have already faced this problem in their life, you can learn effective solutions to tackle and respond to all types of cyber abuse and bullying. </p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    <hr>
                    <div class="intro-item-wrap wow fadeInRight">
                        <div class="intro-item-icon">
                            <i class="fa fa-heart-o "></i>
                        </div>
                        <div class="intro-item-text">
                            <h3>Gender Violence Support Group</h3>
                            <p style="text-align: justify;">For the people who have experienced gender, domestic or sexual abuse. Gender violence can incorporate emotional, physical, psychological, economic, and/or sexual abuse. To experience efficient recovery outcomes, the victims of gender violence must have access to support groups. Gender violence support groups can help victims find emotional and mental help they require to move on with their lives. The purpose of our support group is to enable people to support each other in identifying signs of abusive behavior and searching for safe and effective solutions.</p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-6 span3 wow rollIn" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: rollIn;">
                	<div class="vs-30"></div>
                	<img class="img-responsive img-circle" src="img/service.jpg">
                </div>
                <div class="col-sm-3 col-md-3 col-lg-3 startAnimation animated fadeInDown" data-animate="fadeInDown">
                    <div class="intro-item-wrap wow fadeInLeft">
                        <div class="intro-item-icon">
                            <i class="fa fa-child"></i>
                        </div>
                        <div class="intro-item-text">
                            <h3>Depression Support Group</h3>
                            <p style="text-align: justify;">Mental coaches and counselors registered on the forum of “Mental Health Support Online” can start a discussion on any mental health topic according to their expertise. Any member of this platform can join the discussion to contribute, ask questions, or share their experience.  The expert guidance and suggestions can help you overcome your mental health issues efficiently and smoothly. </p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    <hr>
                    <div class="intro-item-wrap wow fadeInLeft">
                        <div class="intro-item-icon">
                            <i class="fa fa-thumbs-o-up"></i>
                        </div>
                        <div class="intro-item-text">
                            <h3>Addiction Support Group</h3>
                            <p style="text-align: justify;">This support group is valuable for people recovering from alcohol or drug addiction. Joining an addiction support group together with other treatment programs can significantly improve recovery outcomes. Support groups are fundamental in remaining sober and drug-free for life. Our addiction support groups are often very useful in providing an outlet for helping drug and alcohol addicts to maintain sobriety after rehab. </p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    <hr>
                    <div class="intro-item-wrap wow fadeInLeft">
                       	<div class="intro-item-icon">
                            <i class="fa fa-rocket"></i>
                        </div>
                        <div class="intro-item-text">
                            <h3>Experts Discussions</h3>
                            <p style="text-align: justify;">Mental coaches and counselors registered on the forum of “Mental Health Support Online” can start a discussion on any mental health topic according to their expertise. Any member of this platform can join the discussion to contribute, ask questions, or share their experience.  The expert guidance and suggestions can help you overcome your mental health issues efficiently and smoothly. </p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    <hr>
                    <div class="intro-item-wrap wow fadeInLeft">
                        <div class="intro-item-icon">
                            <i class="fa fa-heart-o "></i>
                        </div>
                  		<div class="intro-item-text">
                           	<h3>Women Support Group</h3>
                            <p style="text-align: justify;">Women experience mental health conditions like anxiety, depression, bipolar disorder, etc at higher rates than men. Both social and biological health factors play a decisive role in women’s mental health. Our women support group is a safe platform for women to explore, share, and discuss their mental health issues. It helps women to regain their confidence, self-belief, and self-respect by connecting and bonding with other women. We promote good mental health through sharing, integrity, and detailed discussion</p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                    <hr>
                    <div class="intro-item-wrap wow fadeInLeft">
                        <div class="intro-item-icon">
                            <i class="fa fa-heart-o "></i>
                        </div>
                        <div class="intro-item-text">
                           	<h3>Integration and Immigration Support </h3>
                            <p style="text-align: justify;">Many studies have stated that mental health problems dominate in immigrants. Immigrant communities face many difficulties, for example, visa issues, discrimination, language difficulties, lower access to health care, etc. Dealing with these problems can lead to serious mental health illness, with individuals having a prior biological susceptibility to mental illness being at a greater risk. At Mental Health Support Online, we provide you a safe platform where people with similar problems meet to share and discuss personal experiences. This approach is very helpful in finding safe and effective solutions for your problems. </p>
                            <a href="contact/Sign up.html" class="btn btn-green btn-effect">Join Here</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--End Support-Group section==================================== -->

    
	<section id="counselor" class="posts section">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 col-md-12 col-lg-12 text-center wow fadeInLeft">  
                	<h2 style="color: black">CONNECT WITH <span style="color:#ff1784;">COACHES & COUNSELORS</span></h2>
                	<p>Mental Health Support Online provides a premier listing of the best mental counselors and coaches. We list reliable and ethical mental health professionals. To register, coaches and counselors are bound to provide their photo and credentials. It’s entirely up to them to reveal or conceal their location in their profile. Coaches and counselors have to pay a certain amount per month to be on this platform. In return, they are free to write blogs, post videos, or start discussions on any topic of their expertise.  Patients can comment, ask questions, and contribute to their topics. Moreover, they can book sessions with coaches or counselors as per their necessities. </p><br>
            	</div>
					<div class="col-sm-12 col-md-12 col-xs-12">
						<div class="row">
							<article class="col-md-4 col-sm-4 col-lg-4 clearfix wow fadeInUp">
								<div class="post-item">
								<a href=" http://www.corona-support-online.de/About/">
									<div class="media-wrapper">
										<img src="img/c1.jpg" alt="amazing caves coverimage" class="img-responsive">
									</div>
									</a>
									<div class="content card-block">
										<p>Hello, thank you for viewing my profile. My name is Lucy. I am a Counselling Psychologist and a passionate Mental health advocate. I would love to connect with people from any part of the world, who are going through a difficult time during this COVID-19 pandemic. Please feel free to connect by clicking on my personal website page
										<a href="http://www.corona-support-online.de/About/">http://www.corona-support-online.de/About/</a>
										</p>
										
										<a href="contact/apoirment.php" class="btn btn-green btn-effect" style="background-color: green">CONSULT </a>
									</div>
								</div>						
							</article>
					<!-- /single blog post -->
					
					<!-- single blog post -->
					<article class="col-md-4 col-sm-4 col-lg-4 wow fadeInUp">
						<div class="post-item">
							<div class="media-wrapper">
								<img src="img/consult2.jpg" alt="amazing caves coverimage" class="img-responsive">
							</div>
							
							<div class="content text">
								<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non skateboard dolor brunch.
								</p>
								<a href="contact/apoirment.php" class="btn btn-green btn-effect" style="background-color: green">CONSULT </a>
							</div>
						</div>						
					</article>
					<!-- end single blog post -->
					
					<!-- single blog post -->
					<article class="col-md-4 col-sm-4 col-lg-4 wow fadeInUp">
						<div class="post-item">
							<div class="media-wrapper">
								<img src="img/consult3.jpg" alt="amazing caves coverimage" class="img-responsive">
							</div>
							
							<div class="content">
								<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non skateboard dolor brunch.</p>
								<a href="contact/apoirment.php" class="btn btn-green btn-effect" style="background-color: green">CONSULT </a>
							</div>
						</div>						
					</article>
						</div>
					</div>
					<!-- /section title -->
					<!-- single blog post -->
					<div class="col-md-12 col-sm-12 col-xs-12 wow fadeInUp">
						<div class="row">
							<article class="col-md-4 col-sm-4 col-lg-4 clearfix ">
						<div class="post-item">
							<div class="media-wrapper">
								<img src="img/consult2.jpg" alt="amazing caves coverimage" class="img-responsive">
							</div>
							
							<div class="content">
								<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non skateboard dolor brunch.</p>
								<a href="contact/apoirment.html" class="btn btn-green btn-effect" style="background-color: green">CONSULT </a>
							</div>
						</div>						
					</article>
					<!-- /single blog post -->
					
					<!-- single blog post -->
					<article class="col-md-4 col-sm-4 col-lg-4 wow fadeInUp">
						<div class="post-item">
							<div class="media-wrapper">
								<img src="img/consult3.jpg" alt="amazing caves coverimage" class="img-responsive">
							</div>
							
							<div class="content">
								<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non skateboard dolor brunch.</p>
								<a href="contact/apoirment.php" class="btn btn-green btn-effect" style="background-color: green">CONSULT </a>
							</div>
						</div>						
					</article>
					<!-- end single blog post -->
					
					<!-- single blog post -->
					<article class="col-md-4 col-sm-4 col-lg-4 wow fadeInUp">
						<div class="post-item">
							<div class="media-wrapper">
								<img src="img/consult.jpg" alt="amazing caves coverimage" class="img-responsive">
							</div>
							
							<div class="content">
								<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non skateboard dolor brunch.</p>
								<a href="contact/apoirment.html" class="btn btn-green btn-effect" style="background-color: green">CONSULT </a>
							</div>
						</div>						
					</article>
				</div>
			  </div>
			</div>
		</div>
	</section>

    

	<section id="VOLUNTEER">
		<div class="container-fluid">
			<div class="row">
				<div id="show_4_adv_2_testim_spch_buble_border_carousel" class="carousel slide two_shows_one_move testimonial_spch_babl_brdr_carousel_wrapper" data-ride="carousel" data-interval="2000" data-pause="hover">

            <h2 class="wow fadeInRight"><span style="color: #ff1784">VOLUNTEER</span> LISTENERS</h2>
            <hr>

            <!--========= Wrapper for slides =========-->
            <div class="carousel-inner wow fadeInUp" role="listbox">

                <!--========= 1st slide =========-->
                <div class="item active">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                            <i class="fa fa-quote-left"></i>
                                                Hi, I am a volunteer listener. I am trained in Psychological First Aid. I am available to offer crisis support to anyone going through a rough time at this moment. I am also available to provide information on how to get further support and help. click here and lets chat. Thank you                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 01">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 02">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="col-xs-12 col-sm-6 col-md-6 cloneditem-1">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 03">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 04">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div></div>

                <!--========= 2nd slide =========-->
                <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 03">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 04">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="col-xs-12 col-sm-6 col-md-6 cloneditem-1">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 05">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 06">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div></div>
                
                <!--========= 3rd slide =========-->
                <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 05">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 06">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="col-xs-12 col-sm-6 col-md-6 cloneditem-1">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 07">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 08">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div></div>

                <!--========= 4th slide =========-->
                <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-6">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 07">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 08">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="col-xs-12 col-sm-6 col-md-6 cloneditem-1">
                        <div class="row">
                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                            <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 01">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-6 col-md-6">
                                <div class="testimonial_spch_babl_brdr_carousel_caption">
                                    <div class="row">
                                        <div class="col-xs-12 col-md-12 testimonial_spch_babl_brdr_carousel_text">
                                            <p>
                                                <i class="fa fa-quote-left"></i>
                                                Praesent sagittis, justo id malesuada tincidunt, ipsum leo elementum risus, at pulvinar ante urna et sem. Proin posuere metus sed tellus. Class aptent taciti sociosqu ad litora torquent.
                                            </p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xs-4 col-sm-4 col-md-4 testimonial_spch_babl_brdr_carousel_image">
                                            <img src="img/Volunteer listener.jpg" alt="slider 02">
                                        </div>
                                        <div class="col-xs-8 col-sm-8 col-md-8 testimonial_spch_babl_brdr_carousel_author">
                                            <h5>Avater</h5>
                                            <!--<a href="#">web developer</a>-->
                                            <!--<ul class="testimonial_spch_babl_brdr_rating">
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star"></i></li>
                                                <li><i class="fa fa-star-half-o"></i></li>
                                            </ul>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--======= Navigation Buttons =========-->

            <!--======= Left Button =========-->
            <a class="left carousel-control testimonial_spch_babl_brdr_carousel_control_left" href="#show_4_adv_2_testim_spch_buble_border_carousel" role="button" data-slide="prev">
                <span class="fa fa-angle-left testimonial_spch_babl_brdr_carousel_control_icons" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>

            <!--======= Right Button =========-->
            <a class="right carousel-control testimonial_spch_babl_brdr_carousel_control_right" href="#show_4_adv_2_testim_spch_buble_border_carousel" role="button" data-slide="next">
                <span class="fa fa-angle-right testimonial_spch_babl_brdr_carousel_control_icons" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>

        </div>
			</div>
		</div>
	</section>

	<section id="blog_part"><!--Start Blog section==================================== -->
   		<div class="container-fluid"> 
        	<div class="row">
            	<div class="col-lg-12 col-lg-offset text-center">  
                	<h2 class="wow fadeInLeft"><span class="ion-minus" style="color:#ff1784;">Blog</span> Posts<span class="ion-minus wow fadeInDown"></span></h2>
                	<p class="wow fadeInRight">Professional coaches and counselors can write or share articles and blog posts about mental health according to their area of specialization. These articles and blogs will keep you updated about the latest mental health researches and news. If you or your loved one is battling with a mental condition, you should follow expert mental health blogs. These will provide you a new way of dealing with your mental health problems.</p><br>
            	</div> 
             	<div class="carousel slide wow fadeInUp" data-ride="carousel">
             	<!-- Carousel items -->
             		<div class="carousel-inner">
                		<div class="item active">
                      		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         		<div class="card text-center">
	                            	<img class="card-img-top" src="img/blogs.jpg" alt="" width="100%">
	                            	<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
	                                	<a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
	                            	</div>
                         		</div>
                      		</div>
	                       <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         		<div class="card text-center">
                            		<img class="card-img-top" src="img/Blog2.jpeg" alt="" width="100%">
                            		<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
                                		<a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
                            		</div>
                         		</div>
                      		</div>
                       		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         		<div class="card text-center">
                            		<img class="card-img-top" src="img/blogs.jpg" alt="" width="100%">
                            		<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
		                                <a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
                            		</div>
                         		</div>
                      		</div>
	                       	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
	                         	<div class="card text-center">
	                            	<img class="card-img-top" src="img/Blog2.jpeg" alt="" width="100%">
	                            	<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
		                                <a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
	                            	</div>
	                         	</div>
	                      	</div>
                		</div> <!-- item -->
                		<div class="item">
                        	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         		<div class="card text-center">
                            		<img class="card-img-top" src="img/blogs.jpg" alt="" width="100%">
                            		<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
		                                <a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
                            		</div>
                         		</div>
                      		</div>
                       		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         		<div class="card text-center">
                            		<img class="card-img-top" src="img/Blog2.jpeg" alt="" width="100%">
                            		<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
		                                <a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
                            		</div>
                         		</div>
                      		</div>
                       		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         		<div class="card text-center">
                            		<img class="card-img-top" src="img/blogs.jpg" alt="" width="100%">
                            		<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
		                                <a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
                            		</div>
                         		</div>
                      		</div>
                       		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                         		<div class="card text-center">
                            		<img class="card-img-top" src="img/Blog2.jpeg" alt="" width="100%">
                            		<div class="card-block">
		                                <!--<h4 class="card-title">Post Title</h4>-->
		                                <p class="card-text">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa.</p>
		                                <a href="#" class="btn btn-green btn-effect" style="background-color: #7F0055">POST</a>
                            		</div>
                         		</div>
                      		</div>
                		</div> <!-- item -->
                	</div>
            	</div>
    		</div>
    	</div>
	</section><!--End blog section==================================== -->
    

	<section class="contact-us" id="contact">
		<div class="container-fluid">
			<div class="row">
				
				<!-- section title -->
				<div class="title text-center wow fadeInRight">
					<h2>Get In <span style="color:#ff1784">Touch</span></h2>
					<p>If you or someone you know is experiencing serious mental health issues, get in touch with us today for immediate assistance. Heal your mentality, insight, and sentiments by joining the best online mental health support platform. Fill out the form and begin your healing journey with Mental Health Support Online now!</p>
					<div class="border"></div>
				</div>
				<!-- /section title -->
				
				<!-- Contact Details -->
				<div class="contact-details col-md-6 wow fadeInLeft">
					<h3>Contact Details</h3>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam, vero, provident, eum eligendi blanditiis ex explicabo vitae nostrum facilis asperiores dolorem illo officiis ratione vel fugiat dicta laboriosam labore adipisci.</p>
					<!--<ul class="contact-short-info">
						<li>
							<i class="tf-ion-ios-home"></i>
							<span>Khaja Road, Bayzid, Chittagong, Bangladesh</span>
						</li>
						<li>
							<i class="tf-ion-android-phone-portrait"></i>
							<span>Phone: +880-31-000-000</span>
						</li>
						<li>
							<i class="tf-ion-android-globe"></i>
							<span>Fax: +880-31-000-000</span>
						</li>
						<li>
							<i class="tf-ion-android-mail"></i>
							<span>Email: hello@meghna.com</span>
						</li>
					</ul>-->
					<!-- Footer Social Links -->
					<div class="social-icon span3 wow rollIn" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: rollIn;">
						<a href="#"><i id="social-fb" class="fa fa-facebook-square fa-3x social"></i></a>
                        <a href="#"><i id="social-tw" class="fa fa-twitter-square fa-3x social"></i></a>
                        <a href="#"><i id="social-gp" class="fa fa-google-plus-square fa-3x social"></i></a>
                        <a href="#"><i id="social-em" class="fa fa-envelope-square fa-3x social"></i></a>
					</div>
					<!--/. End Footer Social Links -->
				</div>
				<!-- / End Contact Details -->
					
				<!-- Contact Form -->
				<div class="contact-form col-md-6 ">
					<form id="contact-form" method="post" action="Index.php" role="form">
					
						<div class="form-group wow fadeInRight">
							<input type="text" placeholder="Your Name" class="form-control" name="Name" id="name" required>
						</div>
						
						<div class="form-group wow fadeInLeft">
							<input type="email" placeholder="Your Email" class="form-control" name="Email" id="email" required>
						</div>
						
						<div class="form-group wow fadeInRight">
							<input type="text" placeholder="Subject" class="form-control" name="Subject" id="subject" required>
						</div>
						
						<div class="form-group wow fadeInLeft">
							<textarea rows="6" placeholder="Message" class="form-control" name="Message" id="message" required></textarea>	
						</div>
						
						<div id="mail-success" class="success">
							Thank you. The Mailman is on His Way :)
						</div>
						
						<div id="mail-fail" class="error">
							Sorry, don't know what happened. Try later :(
						</div>
						
						<div id="cf-submit">
							<input type="submit" id="contact-submit" name="save" class="btn btn-transparent" value="Submit">
						</div>						
						
					</form>
				</div>
				<!-- ./End Contact Form -->
			
			</div> <!-- end row -->
		</div> <!-- end container -->
	</section>
	
	<footer id="footer" class="footer bg-overlay wow fadeInUp" >
			<div class="footer-main">
				<div class="container-fluid">
					<div class="row">
						<div class="title text-center wow fadeInRight">
                            <h2>Watch<span style="color:#ff1784">Video</span></h2>
                            <p>Mental Health Support Online enables members and coaches to post videos of lectures, seminars, and discussions on any mental health-related topic. Every member of this platform will have free access to all such videos.</p>
                            <div class="border"></div>
                        </div>
						<div class="col-sm-12 col-md-12 col-xs-12">
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/NhkdsEcaf9k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/j33nPvbaah4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/cBVWSY6En-o" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/NVqemsHMF3A" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
						</div>
						<div class="col-sm-12 col-md-12 col-xs-12">
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/1nrcomG6New" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/Akt7-v8gD-k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/NhkdsEcaf9k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
							<div class="col-sm-3 col-md-3 col-lg-3">
								<div class="gellary_video">
									<iframe width="100%" height="auto" src="https://www.youtube.com/embed/j33nPvbaah4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								</div>
							</div>
						</div>


						

					</div><!-- Row end -->
				</div><!-- Container end -->
			</div><!-- Footer main end -->

			<div class="copyright">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-6">
							<div class="copyright-info">
								<span style="line-height: 3;word-spacing: 5px;color: white;font-weight: 900;">Copyright © 2020 <a href="#" style="color: #8bff00;">Coaching & Emotional Support</a></span><!-- Design and Development by Md Salman-->
							</div>
						</div>

						<div class="col-xs-12 col-sm-6">
							<div class="footer-menu">
								<ul class="nav unstyled">
									<li><a href="about.html" style="color: color: #fff;">About</a></li>
									<li><a href="faq.html" style="color: color: #fff;">Faq</a></li>
									<li><a href="news-left-sidebar.html" style="color: color: #fff;">Blog</a></li>
								</ul>
							</div>
						</div>
					</div><!-- Row end -->
					
				</div><!-- Container end -->
			</div><!-- Copyright end -->
			<div class="scrollup" href="#"><i class="fa fa-angle-double-up" aria-hidden="true"></i></div>
		</footer>



<!-- Essential jQuery Plugins================================================== -->
<!-- Main jQuery -->
<script src="js/jquery.min.js"></script>
<!--<script src="js/jquery-1.11.1.min.js"></script>-->
<!--<script src="js/bootstrap.min.js"></script>-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<!-- Single Page Nav -->
<script src="js/jquery.singlePageNav.min.js"></script>
<!-- Owl Carousel -->
 <script src="js/owl.carousel.min.js"></script>
<!-- jquery easing -->
<script src="js/isotope.pkgd.min.js"></script>
<script src="js/jquery.easing.min.js"></script>
<!-- Fullscreen slider -->
<script src="js/jquery.slitslider.js"></script>
<script src="js/jquery.ba-cond.min.js"></script>
<script src="js/main.js"></script>
<script src="js/floating-totop-button.js"></script>
<script src="js/wow.js"></script>
<script src="js/smoth.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/smoth_scrooling.js"></script>
</body>
</html>

<?php
	include('config/db.php');

    if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	
$Name= $_POST['Name'];
$Email = $_POST['Email'];
$Subject= $_POST['Subject'];
$Message = $_POST['Message'];
$s=2;

if($Name!=null)
{   $add_user = "INSERT INTO contactus(Name,Email,Subject,Message) 
	VALUES ('$Name','$Email','$Subject','$Message')";
	$user = mysqli_query($conn,$add_user);
	
    // echo $add_user;

 
echo '<script language="javascript">';
echo ' swal({
                    title: "Thanks!",
                    text: "You Contact us",
                    icon: "success"
                    });';
echo '</script>';

echo "<script>windows.href='index.php'</script>";
if(!$user)

{
	
	
echo '<script language="javascript">';
echo ' swal({
                    title: "Error!",
                    text: "Try Again",
                    icon: "Sorry"
                    });';
echo '</script>';
}
}}
?>

